﻿namespace SoborniyProject.exceptions
{
    public class Base
    {
        
    }
}