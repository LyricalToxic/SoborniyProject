﻿namespace SoborniyProject.exceptions.invalid
{
    public class InvalidSessionKey
    {
        
    }
}